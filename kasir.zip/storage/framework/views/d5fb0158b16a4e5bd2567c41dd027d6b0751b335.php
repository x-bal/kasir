

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">Tambah Transaksi</div>

            <div class="card-body">
                <form action="<?php echo e(route('order.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label for="barang">Barang</label>
                        <select name="barang" id="barang" class="form-control select2">
                            <option disabled selected>-- Pilih barang --</option>
                            <?php $__currentLoopData = $stok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($stk->barang->id); ?>"><?php echo e($stk->barang->kode_barang); ?> | <?php echo e($stk->barang->nama_barang); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <?php $__errorArgs = ['barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="qty">Qty</label>
                        <input type="number" name="qty" id="qty" class="form-control">
                    </div>

                    <button type="submit" class="btn btn-sm btn-primary btn-tambah">Tambah</button>
                </form>

            </div>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                List Order
            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Barang</th>
                                <th>Qty</th>
                                <th>Harga</th>
                                <th>Disc</th>
                                <th>Sub Total</th>
                                <th>Opsi</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($order->barang->nama_barang); ?></td>
                                <td><?php echo e($order->qty); ?></td>
                                <td>Rp. <?php echo number_format($order->barang->harga_jual, 0, ',', '.'); ?></td>
                                <td><?php echo e($order->barang->diskon); ?>%</td>
                                <td>Rp. <?php echo number_format($order->qty * $order->barang->harga_jual, 0, ',', '.'); ?></td>
                                <td>
                                    <form action="<?php echo e(route('order.destroy', $order->id)); ?>" method="post" style="display: inline;">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-times"></i></button>
                                    </form>
                                </td>
                            </tr>
                            <?php
                            $total += $order->qty * $order->barang->harga_jual
                            ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7">
                                    <p class="text-center">Tidak ada list order.</p>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <form action="<?php echo e(route('transaksi.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <div class="col-md-6">
                            <label for="total">Total Bayar</label>
                            <input type="number" name="total" id="total" value="<?php echo e($total); ?>" class="form-control" readonly>

                            <?php $__errorArgs = ['total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-md-6">
                            <label for="member">Member</label>
                            <select name="member_id" id="member" class="form-control select2">
                                <option disabled selected>-- Pilih Member --</option>
                                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($member->id); ?>"><?php echo e($member->nama_member); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-6">
                            <label for="bayar">Bayar</label>
                            <input type="number" name="bayar" id="bayar" class="form-control">

                            <?php $__errorArgs = ['bayar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label for="kembalian">Kembalian</label>
                            <input type="number" name="kembalian" id="kembalian" class="form-control" readonly>

                            <?php $__errorArgs = ['kembalian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-sm btn-primary">Transaksi</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-10">

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>
    $("#bayar").on('keyup', function() {
        var bayar = parseInt($("#bayar").val());
        var total = parseInt($("#total").val());

        var kembalian = bayar - total;
        $("#kembalian").val(kembalian)
    });

    $("#member").on('change', function() {
        var id = $(this).val();

        $.ajax({
            method: 'GET',
            url: '/member/get/' + id,
            success: function(result) {
                var total = parseInt($("#total").val());
                var disc = parseInt(result.disc);

                var totalDisc = (total * disc) / 100;

                var all = Math.round(total - totalDisc);

                $("#total").empty();
                $("#total").val(all);
            }
        })
    })

    const select = $('.select2').select2();

    if ($('#barang').hasClass("select2-hidden-accessible")) {
        $('#barang').select2('open');
    }
    $("#barang").on("focus", function() {
        $example.select2("open");
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' => 'Tambah Transaksi'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\kasir\resources\views/transaksi/create.blade.php ENDPATH**/ ?>