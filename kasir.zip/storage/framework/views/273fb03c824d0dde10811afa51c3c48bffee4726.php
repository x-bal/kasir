

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-10">
        <div class="card">
            <div class="card-header">Tambah Transaksi</div>

            <div class="card-body">
                <form action="<?php echo e(route('order.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                    </div>
                    <div class="form-group row">
                        <div class="col-md-6">
                            <label for="barang">Barang</label>
                            <select name="barang" id="barang" class="form-control select2">
                                <option disabled selected>-- Pilih barang --</option>
                                <?php $__currentLoopData = $stok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($stk->barang->id); ?>"><?php echo e($stk->barang->nama_barang); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label for="qty">Qty</label>
                            <input type="number" name="qty" id="qty" class="form-control">
                        </div>
                    </div>

                    <button type="submit" class="btn btn-sm btn-primary btn-tambah">Tambah</button>
                </form>

            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-10">
        <div class="card">
            <div class="card-header">
                List Order
            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Barang</th>
                                <th>Qty</th>
                                <th>Harga</th>
                                <th>Disc</th>
                                <th>Sub Total</th>
                                <th>Opsi</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($order->barang->nama_barang); ?></td>
                                <td><?php echo e($order->qty); ?></td>
                                <td>Rp. <?php echo number_format($order->barang->harga_jual, 0, ',', '.'); ?></td>
                                <td><?php echo e($order->barang->diskon); ?></td>
                                <td>Rp. <?php echo number_format($order->qty * $order->barang->harga_jual, 0, ',', '.'); ?></td>
                                <td>
                                    <form action="<?php echo e(route('order.destroy', $order->id)); ?>" method="post" style="display: inline;">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-times"></i></button>
                                    </form>
                                </td>
                            </tr>
                            <?php
                            $total += $order->qty * $order->barang->harga_jual
                            ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p>Tidak ada list order.</p>
                            <?php endif; ?>
                        </tbody>

                        <tfoot>
                            <tr>
                                <td colspan="5"></td>
                                <td colspan="2">Total : Rp. <?php echo number_format($total, 0, ',', '.'); ?></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>

                <form action="<?php echo e(route('transaksi.update', $transaksi->id)); ?>" method="post">
                    <?php echo method_field('PATCH'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <div class="col-md-6">
                            <label for="total">Total Bayar</label>
                            <input type="number" name="total" id="total" value="<?php echo e($total); ?>" class="form-control" readonly>
                        </div>

                        <div class="col-md-6">
                            <label for="member">Member</label>
                            <select name="member_id" id="member" class="form-control">
                                <option disabled selected>-- Pilih Member --</option>
                                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($transaksi->member_id == $member->id): ?>
                                <option value="<?php echo e($member->id); ?>" selected><?php echo e($member->nama_member); ?></option>
                                <?php else: ?>
                                <option value="<?php echo e($member->id); ?>"><?php echo e($member->nama_member); ?></option>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-6">
                            <label for="bayar">Bayar</label>
                            <input type="number" name="bayar" id="bayar" class="form-control" value="<?php echo e($transaksi->bayar); ?>">
                        </div>
                        <div class="col-md-6">
                            <label for="kembalian">Kembalian</label>
                            <input type="number" name="kembalian" id="kembalian" class="form-control" readonly value="<?php echo e($transaksi->kembalian); ?>">
                        </div>
                    </div>

                    <button type="submit" class="btn btn-sm btn-primary">Transaksi</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<script>
    $("#bayar").on('keyup', function() {
        var bayar = parseInt($("#bayar").val());
        var total = parseInt($("#total").val());

        var kembalian = bayar - total;
        $("#kembalian").val(kembalian)
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' => 'Tambah Transaksi'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\kasir\resources\views/transaksi/edit.blade.php ENDPATH**/ ?>