

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header bg-primary text-light">Data Distributor</div>

            <div class="card-body mt-3">
                <a href="<?php echo e(route('distributor.create')); ?>" class="btn btn-sm btn-primary mb-3">Tambah Distributor</a>
                <table class="table table-bordered table-striped" id="table">
                    <thead>
                        <tr>
                            <th></th>
                            <th>No</th>
                            <th>Nama Distributor</th>
                            <th>Alamat</th>
                            <th>Telp</th>
                            <th>Opsi</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $distributor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $distri): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($distri->nama_distributor); ?></td>
                            <td><?php echo e($distri->alamat); ?></td>
                            <td><?php echo e($distri->telp); ?></td>
                            <td>
                                <a href="<?php echo e(route('distributor.edit', $distri->id)); ?>" class="btn btn-sm btn-success"><i class="fas fa-edit"></i></a>
                                <form action="<?php echo e(route('distributor.destroy', $distri->id)); ?>" method="post" style="display: inline;" class="delete-form">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-sm btn-danger btn-delete"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' => 'Data Distributor'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\kasir\resources\views/distributor/index.blade.php ENDPATH**/ ?>