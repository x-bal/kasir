

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">Data Transaksi</div>

            <div class="card-body">
                <?php if(auth()->user()->level->level == 'admin'): ?>
                <a href="<?php echo e(route('transaksi.create')); ?>" class="btn btn-sm btn-primary mb-3">Tambah Transaksi</a>
                <?php endif; ?>
                <table class="table table-bordered table-striped" id="table">
                    <thead>
                        <tr>
                            <th></th>
                            <th>No</th>
                            <th>Tanggal</th>
                            <th>Invoice</th>
                            <th>Kasir</th>
                            <th>Jumlah</th>
                            <th>Opsi</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($trx->created_at); ?></td>
                            <td><?php echo e($trx->invoice); ?></td>
                            <td><?php echo e($trx->user->nama); ?></td>
                            <td>Rp. <?php echo number_format($trx->total, 0, ',', '.'); ?></td>
                            <td>
                                <a href="<?php echo e(route('transaksi.show', $trx->id)); ?>" class="btn btn-sm btn-info"><i class="fas fa-eye"></i></a>
                                <?php if(auth()->user()->level->level == 'admin'): ?>
                                <a href="<?php echo e(route('transaksi.print', $trx->id)); ?>" class="btn btn-sm btn-secondary"><i class="fas fa-print"></i></a>
                                <a href="<?php echo e(route('transaksi.edit', $trx->id)); ?>" class="btn btn-sm btn-success"><i class="fas fa-edit"></i></a>
                                <form action="<?php echo e(route('transaksi.destroy', $trx->id)); ?>" method="post" style="display: inline;" class="delete-form">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-sm btn-danger btn-delete"><i class="fas fa-trash"></i></button>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' => 'Data Transaksi'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\kasir\resources\views/transaksi/index.blade.php ENDPATH**/ ?>