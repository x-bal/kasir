


<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">History Transaksi <?php echo e($member->nama_member); ?></div>

            <div class="card-body">
                <table class="table table-bordered table-striped" id="table">
                    <thead>
                        <tr>
                            <th></th>
                            <th>No</th>
                            <th>Tanggal</th>
                            <th>Invoice</th>
                            <th>Total</th>
                            <th>Opsi</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($hst->created_at); ?></td>
                            <td><?php echo e($hst->invoice); ?></td>
                            <td>Rp. <?php echo number_format($hst->total, 0, ',', '.'); ?></td>
                            <td><a href="<?php echo e(route('transaksi.show', $hst->id)); ?>" class="btn btn-sm btn-info"><i class="fas fa-arrow-right"></i></a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' => 'History Transaksi Member'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\kasir\resources\views/member/history.blade.php ENDPATH**/ ?>