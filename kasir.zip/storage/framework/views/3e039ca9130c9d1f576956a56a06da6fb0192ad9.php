

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">Data Barang</div>

            <div class="card-body">
                <a href="<?php echo e(route('barang.create')); ?>" class="btn btn-sm btn-primary mb-3">Tambah Barang</a>
                <a href="<?php echo e(route('barang.printCode')); ?>" class="btn btn-sm btn-primary mb-3"><i class="fas fa-print"></i> Print Barcode</a>
                <table class="table table-bordered table-striped" id="table">
                    <thead>
                        <tr>
                            <th></th>
                            <th>No</th>
                            <!-- <th>Kode Barang</th> -->
                            <th>Barcode</th>
                            <th>Nama Barang</th>
                            <th>Harga Pokok</th>
                            <th>PPN</th>
                            <th>Diskon</th>
                            <th>Harga Jual</th>
                            <th>Opsi</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td><?php echo e($loop->iteration); ?></td>
                            <!-- <td><?php echo e($brg->kode_barang); ?></td> -->
                            <td class="text-center text-dark">
                                <img src="data:image/png;base64,<?php echo e(DNS1D::getBarcodePNG($brg->kode_barang, 'C128')); ?>" alt="barcode" width="120" />
                                <small style="font-size: 11px;"><?php echo e($brg->kode_barang); ?></small>
                            </td>
                            <td><?php echo e($brg->nama_barang); ?></td>
                            <td>Rp. <?php echo number_format($brg->harga_pokok, 0, ',', '.'); ?></td>
                            <td class="text-center"><?php echo e($brg->ppn); ?>%</td>
                            <td class="text-center"><?php echo e($brg->diskon); ?>%</td>
                            <td>Rp. <?php echo number_format($brg->harga_jual, 0, ',', '.'); ?></td>
                            <td>
                                <a href="<?php echo e(route('barang.edit', $brg->id)); ?>" class="btn btn-sm btn-success"><i class="fas fa-edit"></i></a>
                                <a href="<?php echo e(route('barang.print', $brg->id)); ?>" class="btn btn-sm btn-secondary"><i class="fas fa-print"></i></a>
                                <form action="<?php echo e(route('barang.destroy', $brg->id)); ?>" method="post" style="display: inline;" class="delete-form">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-sm btn-danger btn-delete"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' => 'Data Barang'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\kasir\resources\views/barang/index.blade.php ENDPATH**/ ?>