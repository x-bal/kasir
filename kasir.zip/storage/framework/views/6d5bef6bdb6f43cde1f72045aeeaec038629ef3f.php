

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header bg-primary text-light">Data Member</div>

            <div class="card-body mt-3">
                <a href="<?php echo e(route('member.create')); ?>" class="btn btn-sm btn-primary mb-3">Tambah Member</a>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped" id="table">
                        <thead>
                            <tr>
                                <th></th>
                                <th>No</th>
                                <th class="text-center" style="width: 120px;">Kode Member</th>
                                <th style="width: 250px;">Nama Member</th>
                                <th>Telp</th>
                                <!-- <th>Disc</th> -->
                                <!-- <th style="width: 200px;">Member Sejak</th> -->
                                <th>Opsi</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td></td>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td class="text-center text-dark">
                                    <img src="data:image/png;base64,<?php echo e(DNS1D::getBarcodePNG($member->kode_member, 'C128')); ?>" alt="barcode" width="120" />
                                    <small><?php echo e($member->kode_member); ?></small>
                                </td>
                                <td><?php echo e($member->nama_member); ?></td>
                                <td><?php echo e($member->telp); ?></td>
                                <!-- <td><?php echo e($member->disc); ?>%</td> -->
                                <!-- <td><?php echo e($member->created_at->diffForHumans()); ?></td> -->
                                <td>
                                    <a href="<?php echo e(route('member.show', $member->id)); ?>" class="btn btn-sm btn-primary"><i class="fas fa-eye"></i></a>
                                    <a href="<?php echo e(route('member.print', $member->id)); ?>" class="btn btn-sm btn-secondary"><i class="fas fa-print"></i></a>
                                    <a href="<?php echo e(route('member.edit', $member->id)); ?>" class="btn btn-sm btn-success"><i class="fas fa-edit"></i></a>
                                    <?php if(auth()->user()->level == 'admin'): ?>
                                    <a href="<?php echo e(route('member.history', $member->id)); ?>" class="btn btn-sm btn-info"><i class="fas fa-cash-register"></i></a>
                                    <form action="<?php echo e(route('member.destroy', $member->id)); ?>" method="post" class="delete-form" style="display: inline;">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-sm btn-danger btn-delete"><i class="fas fa-trash"></i></button>
                                    </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' => 'Data Member'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\kasir\resources\views/member/index.blade.php ENDPATH**/ ?>