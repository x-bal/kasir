

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Detail Transaksi</h4>
            </div>
            <div class="card-content">
                <div class="card-body">
                    <form class="form form-horizontal">
                        <div class="form-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <label>Invoice</label>
                                </div>
                                <div class="col-md-8 form-group">
                                    <input type="text" id="invoice" class="form-control" value="<?php echo e($transaksi->invoice); ?>" disabled>
                                </div>
                                <div class="col-md-4">
                                    <label>Tanggal</label>
                                </div>
                                <div class="col-md-8 form-group">
                                    <input type="text" id="tangal" class="form-control" value="<?php echo e($transaksi->created_at); ?>" disabled>
                                </div>
                                <div class="col-md-4">
                                    <label>Kasir</label>
                                </div>
                                <div class="col-md-8 form-group">
                                    <input type="text" id="kasir" class="form-control" value="<?php echo e($transaksi->user->nama); ?>" disabled>
                                </div>
                                <div class="col-md-4">
                                    <label>Member</label>
                                </div>
                                <div class="col-md-8 form-group">
                                    <input type="text" id="" class="form-control" value="<?php echo e($transaksi->member ? $transaksi->member->nama_member : '-'); ?>" disabled>
                                </div>
                                <div class="col-md-4">
                                    <label>Total</label>
                                </div>
                                <div class="col-md-8 form-group">
                                    <input type="text" id="invoice" class="form-control" value="Rp. <?php echo number_format($transaksi->total, 0, ',', '.'); ?>" disabled>
                                </div>
                                <div class="col-md-4">
                                    <label>Bayar</label>
                                </div>
                                <div class="col-md-8 form-group">
                                    <input type="text" id="invoice" class="form-control" value="Rp. <?php echo number_format($transaksi->bayar, 0, ',', '.'); ?>" disabled>
                                </div>
                                <div class="col-md-4">
                                    <label>Kembalian</label>
                                </div>
                                <div class="col-md-8 form-group">
                                    <input type="text" id="invoice" class="form-control" value="Rp. <?php echo number_format($transaksi->kembalian, 0, ',', '.'); ?>" disabled>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <label>Barang</label>
                                </div>
                                <div class="col-md-8">
                                    <table class="table">
                                        <tr>
                                            <th>Nama Barang</th>
                                            <th>Qty</th>
                                            <th>Sub Total</th>
                                        </tr>
                                        <?php $__currentLoopData = $transaksi->orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($order->barang->nama_barang); ?></td>
                                            <td><?php echo e($order->qty); ?></td>
                                            <td>Rp. <?php echo number_format($order->qty * $order->barang->harga_jual, 0, ',', '.'); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </div>
                            </div>
                            <div class="row">

                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' => 'Detail Transaksi'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\kasir\resources\views/transaksi/show.blade.php ENDPATH**/ ?>